@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Contact Us</h1>
        <p>This is the contact page.</p>
        <!-- Add your contact form or content here -->
    </div>
@endsection
